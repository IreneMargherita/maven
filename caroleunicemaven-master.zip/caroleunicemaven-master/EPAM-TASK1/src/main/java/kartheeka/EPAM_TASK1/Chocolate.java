package RamMohanReddy.EPAM_TASK1;

public class Chocolate extends Sweets{

	Chocolate(String name, int weight, int cost) {
		super(name, weight, cost);
		// TODO Auto-generated constructor stub
	}

	@Override
	String getType() {
		// TODO Auto-generated method stub
		return "chocolate";
	}

}